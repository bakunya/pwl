<footer>
    <p>Ini adalah footer</p>
</footer>

<?= $this->include("partials/scripts/header.php") ?>
<?= $this->include("partials/scripts/sidebar.php") ?>
<?= $this->include("partials/scripts/footer.php") ?>
</body>
</html>