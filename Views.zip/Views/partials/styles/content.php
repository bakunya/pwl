<style>
    #content {
        max-width: 100%;
        padding: 0 2%;
        margin: 0 auto;
        box-sizing: border-box;
        min-height: 80vh;
    }

    #content h2 {
        font-size: 3vw;
        text-align: justify;
    }

    #content p {
        font-size: 2vw;
        text-align: justify;
    }

    @media (max-width: 768px) {
        #content h2  {
            font-size: 4vw;
        }

        #content h2  {
            font-size: 3vw;
        }
    }
</style>