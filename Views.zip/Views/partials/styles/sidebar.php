<style>
    #sidebar {
        width: 20%;
        background-color: #f1f1f1;
        padding: 20px;
    }

    #sidebar ul {
        list-style-type: none;
        padding: 2%;
    }

    #sidebar li {
        margin-bottom: 1%;
    }

    #sidebar a {
        display: block;
        text-decoration: none;
        color: #333;
        font-weight: 2vw;
        white-space: nowrap;
        margin-bottom: 2vw;
    }

    @media (max-width: 768px) {
        #sidebar {
            width: 100%;
        }

        #sidebar ul {
            padding: 2%;
        }

        #sidebar li {
            margin-bottom: 2%;
        }
    }
</style>