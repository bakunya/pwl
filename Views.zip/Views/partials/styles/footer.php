<style>
    footer {
        background-color: #333;
        color: #fff;
        padding: 1%;
        text-align: center;
        font-size: 2vw;
    }

    @media (max-width: 768px) {
        footer {
            font-size: 3vw;
        }
    }
</style>