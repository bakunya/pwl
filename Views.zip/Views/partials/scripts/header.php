<script>
    // const s = document.getElementById("sidebar")
    // const c = document.getElementById("content")

    // s.style.float = "left"
    // c.style.marginLeft = "20%"
</script>