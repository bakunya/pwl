<?= $this->include("partials/header.php") ?>

<div id="container" class="container">
    <?= $this->include("partials/sidebar.php") ?>
    <?= $this->include("partials/content.php") ?>
</div>

<?= $this->include("partials/footer.php") ?>